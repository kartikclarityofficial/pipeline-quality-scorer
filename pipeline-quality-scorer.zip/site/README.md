# Pipeline Quality Scorer™

Static 5-page site. No build step, no framework, no dependencies to install —
just HTML, one shared stylesheet, and Google Fonts.

## Pages
- `/` — Executive dashboard
- `/pipeline` — Pipeline inspection
- `/relationships` — Relationship coverage
- `/diagnostic` — Scoring diagnostic
- `/actions` — Action queue

## Deploy on Vercel
1. Push this folder to a GitHub repo.
2. Import the repo in Vercel. Framework preset: **Other** (no build command needed).
3. `vercel.json` already enables clean URLs, so the nav links (`/pipeline`,
   `/relationships`, etc.) resolve without `.html`.

## Local preview
Just open `index.html` in a browser, or run any static server, e.g.
`python3 -m http.server` from this folder.

## Design system
All tokens (colors, type, spacing) live in `assets/styles.css`. All five
pages share one header/footer/nav so styling stays consistent — edit the
stylesheet once and every page updates.
