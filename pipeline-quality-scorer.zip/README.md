# Pipeline Quality Scorer™

Static 5-page site. No build step, no framework, no dependencies — just
HTML, one shared stylesheet, and Google Fonts. All links are relative, so
it works identically whether it's hosted at a domain root or under a
subpath like `github.io/your-repo-name/`.

## Pages
- `index.html` — Executive dashboard
- `pipeline.html` — Pipeline inspection
- `relationships.html` — Relationship coverage
- `diagnostic.html` — Scoring diagnostic
- `actions.html` — Action queue

## Deploy on GitHub Pages — important

**Upload the *contents* of this zip directly into the repo root — not
inside a subfolder.** Your repo's top level should look like:

```
your-repo/
├── index.html
├── pipeline.html
├── relationships.html
├── diagnostic.html
├── actions.html
├── assets/
│   └── styles.css
├── .nojekyll
└── README.md
```

If `index.html` ends up nested inside a folder (e.g. `your-repo/site/index.html`),
GitHub Pages won't find it at the root and will auto-render `README.md`
instead — that's the "styled README" page instead of your dashboard.

Steps:
1. On GitHub, open your repo → **Add file → Upload files**.
2. Drag in `index.html`, `pipeline.html`, `relationships.html`,
   `diagnostic.html`, `actions.html`, `README.md`, `.nojekyll`, and the
   whole `assets` folder — all at the top level of the file picker, not
   pre-nested in another folder.
3. Commit, then go to **Settings → Pages** and confirm the source branch
   is set (e.g. `main`, root `/`).
4. Visit `https://<username>.github.io/<repo-name>/` — should load the
   dashboard directly.

## Deploy on Vercel (also supported)
Import the repo, framework preset **Other**, no build command. `vercel.json`
enables clean URLs there if you ever want `/pipeline` instead of
`/pipeline.html`.

## Local preview
Open `index.html` directly in a browser, or run
`python3 -m http.server` from this folder.

## Design system
All tokens (colors, type, spacing) live in `assets/styles.css`. All five
pages share the same header/footer/nav markup, so edit the stylesheet
once and every page updates together.

## Known limitation
Opportunity name links (e.g. "Northwind Health") currently point back to
`pipeline.html` — there are no individual opportunity detail pages yet.
Build those as `opportunities/<slug>.html` when ready and repoint the links.
